// jsonld-lint: lint JSON-LD structured data against common schema.org conventions.
// MIT License. https://denverseo.io/open-source/
export const RULES = {Organization:["name","url"],LocalBusiness:["name","address"],ProfessionalService:["name","address"],Person:["name"],WebSite:["name","url"],WebPage:["name"],Article:["headline"],BlogPosting:["headline"],TechArticle:["headline"],Product:["name"],Offer:["price","priceCurrency"],Service:["name"],FAQPage:["mainEntity"],Question:["name","acceptedAnswer"],Answer:["text"],BreadcrumbList:["itemListElement"],ListItem:["position"],Event:["name","startDate","location"],Review:["reviewRating","author"],AggregateRating:["ratingValue"],HowTo:["name","step"],Recipe:["name","image"],VideoObject:["name","thumbnailUrl","uploadDate"],SoftwareApplication:["name"],WebApplication:["name"]};
const URLS = ["url","logo","image","sameAs","item","contentUrl","thumbnailUrl"], DATES = ["datePublished","dateModified","uploadDate","startDate","endDate","priceValidUntil"];
export function lintJsonLd(input) {
  const errors = [], warnings = [], types = [], ids = new Set(); let data;
  try { data = typeof input === "string" ? JSON.parse(input) : input; } catch (e) { return { errors: ["Invalid JSON: " + e.message], warnings, types }; }
  const ctx = Array.isArray(data) ? data[0] && data[0]["@context"] : data["@context"];
  if (!ctx) errors.push('Missing "@context": "https://schema.org"'); else if (!/schema\.org/.test(JSON.stringify(ctx))) warnings.push("@context does not reference schema.org");
  const walk = o => {
    if (!o || typeof o !== "object") return; if (Array.isArray(o)) return o.forEach(walk);
    const t = Array.isArray(o["@type"]) ? o["@type"][0] : o["@type"];
    if (t) { types.push(t); for (const p of RULES[t] || []) if (o[p] === undefined || o[p] === "") errors.push(`${t}: missing ${p}`);
      if (o["@id"] && Object.keys(o).length > 2) { if (ids.has(o["@id"])) warnings.push(`@id ${o["@id"]} defined more than once`); ids.add(o["@id"]); } }
    for (const [k, v] of Object.entries(o)) {
      if (URLS.includes(k) && typeof v === "string" && !/^https?:\/\//.test(v)) errors.push(`${t || "node"}: ${k} should be an absolute URL`);
      if (DATES.includes(k) && typeof v === "string" && !/^\d{4}-\d{2}-\d{2}/.test(v)) errors.push(`${t || "node"}: ${k} should be ISO 8601`);
      if (v && typeof v === "object" && k !== "@context") walk(v);
    }
  };
  walk(Array.isArray(data) ? data : (data["@graph"] || data));
  if (!types.length) errors.push("No @type found");
  return { errors, warnings, types };
}
