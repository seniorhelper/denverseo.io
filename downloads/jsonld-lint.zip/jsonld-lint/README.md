# jsonld-lint

Lint JSON-LD structured data: invalid JSON, missing @context, required properties for 25 common schema.org types, non-absolute URLs, non-ISO dates and duplicate @id definitions. No dependencies.

```js
import { lintJsonLd } from "./jsonld-lint.js";
const { errors, warnings, types } = lintJsonLd(jsonString);
```

Valid is not the same as right: this does not check eligibility for Google rich results. MIT licensed. From https://denverseo.io/open-source/
