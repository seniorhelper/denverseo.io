# robots-ai-check

Evaluate a robots.txt file for search and AI crawlers using RFC 9309 longest-match rules. No dependencies. Works in browsers and Node.js 18+.

```js
import { parseRobots, isAllowed, checkAll } from "./robots-ai-check.js";
const groups = parseRobots(robotsTxt);
isAllowed(groups, "GPTBot", "/blog/"); // { allowed: false, rule: "Disallow: /" }
checkAll(robotsTxt, "/");               // results for 18 crawlers
```

Handles user-agent groups, `*` wildcards, `$` end anchors and Allow-wins ties. MIT licensed. From https://denverseo.io/open-source/
