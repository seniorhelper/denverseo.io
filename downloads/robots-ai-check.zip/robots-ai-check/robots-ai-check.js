// robots-ai-check: evaluate robots.txt rules for search and AI crawlers (RFC 9309 longest-match).
// MIT License. https://denverseo.io/open-source/
export const BOTS = ["Googlebot","Google-Extended","Bingbot","GPTBot","OAI-SearchBot","ChatGPT-User","ClaudeBot","Claude-SearchBot","Claude-User","PerplexityBot","Perplexity-User","Applebot","Applebot-Extended","CCBot","Meta-ExternalAgent","Amazonbot","Bytespider","DuckAssistBot"];
export function parseRobots(txt) {
  const groups = []; let cur = null, lastUA = false;
  for (const line of String(txt).split(/\r?\n/)) {
    const l = line.replace(/#.*$/, "").trim(); if (!l) continue;
    const m = l.match(/^([A-Za-z-]+)\s*:\s*(.*)$/); if (!m) continue;
    const k = m[1].toLowerCase(), v = m[2].trim();
    if (k === "user-agent") { if (!cur || !lastUA) { cur = { ua: [], rules: [] }; groups.push(cur); } cur.ua.push(v.toLowerCase()); lastUA = true; }
    else { lastUA = false; if (cur && (k === "allow" || k === "disallow")) cur.rules.push({ type: k, path: v }); }
  }
  return groups;
}
function matchLen(pattern, path) {
  if (pattern === "") return -1;
  const anchor = pattern.endsWith("$"), body = anchor ? pattern.slice(0, -1) : pattern;
  const re = new RegExp("^" + body.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*") + (anchor ? "$" : ""));
  return re.test(path) ? pattern.length : -1;
}
export function isAllowed(groups, bot, path = "/") {
  const b = bot.toLowerCase();
  let g = groups.filter(x => x.ua.some(u => u !== "*" && (b === u || b.startsWith(u))));
  if (!g.length) g = groups.filter(x => x.ua.includes("*"));
  if (!g.length) return { allowed: true, rule: null };
  let best = null, bl = -1;
  for (const x of g) for (const r of x.rules) { const l = matchLen(r.path, path); if (l > bl || (l === bl && l >= 0 && r.type === "allow")) { bl = l; best = r; } }
  if (!best || bl < 0) return { allowed: true, rule: null };
  return { allowed: best.type === "allow", rule: (best.type === "allow" ? "Allow: " : "Disallow: ") + best.path };
}
export function checkAll(robotsTxt, path = "/") { const g = parseRobots(robotsTxt); return BOTS.map(bot => ({ bot, ...isAllowed(g, bot, path) })); }
